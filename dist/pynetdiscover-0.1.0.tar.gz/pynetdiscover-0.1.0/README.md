# Network Scanner

This Python module allows you to scan devices on your network. It uses the Scapy library to perform a simple ARP scan.

## Installation

You can install the package via pip:

```bash
pip install pynetdiscover
